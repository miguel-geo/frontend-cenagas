﻿var apiUrl = "http://localhost:82/backend-cenagas/public/api/"; // la url del api guardada en el config.json de la aplicacion
var ducto;
var tramo;
var area;
var txtducto;
var txttramo;
var txtarea;
var kminicial;
var kmfinal;
var kmorigen;
var kmdestino;
var ductocon;
var tramocon;
var areacon;
var temaconsulta = "";
var docbasecons = "";
var temaconsultaconstruccion = "";
var temaconsultadisenio = "";
const headers = new Headers({
    'Accept': 'application/json',
    'Content-Type': 'application/json'
});



$(document).ready(function () {
   
   
    llenar_ductos();
    //loadidentificacion();
    $('.custom-file-input').on('change', function(event) {
        var inputFile = event.currentTarget;
        $(inputFile).parent()
            .find('.custom-file-label')
            .html(inputFile.files[0].name);
    }); 

    $('#logoutBtn').click(function() {
        logoutFunction()
    });
    //$('#tablaPersonas').DataTable();
    //$('.dataTables_length').addClass('bs-select');

    document.getElementById("cmbTramo").addEventListener("change", function() {
        var imageElement = document.getElementById("myImage");
        console.log(this.value)
        if (this.value == "1") {
            // Change to the first image
            imageElement.src = "images/tramo1.jpg";
        } else if (this.value == "2") {
            // Change to the second image
            imageElement.src = "images/tramo2.jpg";
        }
    });



    
    var navListItems = $('div.setup-panel div a'),
            allWells = $('.setup-content'),
            allNextBtn = $('.nextBtn');
            
    allWells.hide();

    navListItems.click(function (e) {
        e.preventDefault();
        var $target = $($(this).attr('href')),
                $item = $(this);

        if (!$item.hasClass('disabled')) {
            navListItems.removeClass('btn-primary').addClass('btn-default');
            $item.addClass('btn-primary');
            allWells.hide();
            $target.show();
            $target.find('input:eq(0)').focus();
        }
    });

    allNextBtn.click(function(){
                 var curStep = $(this).closest(".setup-content"),
            curStepBtn = curStep.attr("id"),
            nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
            curInputs = curStep.find("input[type='text'],input[type='url']"),
            isValid = true;

        $(".form-group").removeClass("has-error");
        for(var i=0; i<curInputs.length; i++){
            if (!curInputs[i].validity.valid){
                isValid = false;
                $(curInputs[i]).closest(".form-group").addClass("has-error");
            }
        }

        if (isValid)
            nextStepWizard.removeAttr('disabled').trigger('click');
    });
  

    $('div.setup-panel div a.btn-primary').trigger('click');
    inicializarEventos();
    
   // loadPersonas();
   // $('#loginModal').modal('hide');
    //$(function () {
    //    $('[data-toggle="tooltip"]').tooltip()
    //})
    //$('#formularios').hide();
    //$('#loginModal').show();




    $('#cmbDucto').change(function() {
        
      });


      //$('#cmbTramo').change(function() {
    
      //});


      $('#cmbAreas').change(function() {
        var property = $(this).val();


        const webMethod='areas_unitarias/fetch_kms';
        url=apiUrl+webMethod;
        if (property) {
          
          fetch(url, {
            method: 'POST', // or 'POST', 'PUT', etc.
            headers: headers,
            body: JSON.stringify({'property': property})
          })
              .then(response => response.json())
              .then(data => {
                console.log(data)
                document.getElementById('txtkminicial').value = data[0].km_inicial;
                document.getElementById('txtkmfinal').value = data[0].km_final;
                document.getElementById('txtkmOrigen').value = data[0].km_origen;
                document.getElementById('txtkmDestino').value = data[0].km_destino;

              })
              .catch(error => console.error("Error fetching data: ", error));
        }
      });



});

function showotroMaterial() {
    $('#espMaterial').show();
}


function showtipotecnica() {
    $('#creartipotecnicaunion').show();
}


function showotroTipoUbicacion() {
    $('#creartipoubicacionunion').show();
}

function showproteccioncatodica() {
    $('#crearproteccioncatodica').show();
}

function showotroTipoInstalacion() {
    $('#creartipoinstalacion').show();
}
function espCostura() {
    $('#espCostura').show();
}
function loadAreas() {
    $("#cmbAreas option:not(:first)").remove();
    var property = $("#cmbTramo").val();
    const webMethod = 'areas_unitarias/fetch';
    url = apiUrl + webMethod;
    if (property) {

        fetch(url, {
            method: 'POST', // or 'POST', 'PUT', etc.
            headers: headers,
            body: JSON.stringify({ 'property': property })
        })
            .then(response => response.json())
            .then(data => {

                $("#cmbAreas").empty();
                $('#cmbAreas').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.length; i++) {
                    $('#cmbAreas').append($('<option>', {
                        value: data[i].id,
                        text: data[i].nombre
                    }));
                }
            })
            .catch(error => console.error("Error fetching data: ", error));
    }
}
function loadSegmentosCon() {
    $("#cmbSegmento_con option:not(:first)").remove();
    var property = $("#cmbTramo_con").val();
    const webMethod = 'segmentos/fetch';
    url = apiUrl + webMethod;
    if (property) {

        fetch(url, {
            method: 'POST', // or 'POST', 'PUT', etc.
            headers: headers,
            body: JSON.stringify({ 'property': property })
        })
            .then(response => response.json())
            .then(data => {

                $("#cmbSegmento_con").empty();
                $('#cmbSegmento_con').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.length; i++) {
                    $('#cmbSegmento_con').append($('<option>', {
                        value: data[i].id,
                        text: data[i].clave_segmento
                    }));
                }
            })
            .catch(error => console.error("Error fetching data: ", error));
    }
}
function loadAreasCon() {
    $("#cmbAreas_con option:not(:first)").remove();
    var property = $("#cmbSegmento_con").val();
    const webMethod = 'areas_unitarias/fetchCon';
    url = apiUrl + webMethod;
    if (property) {

        fetch(url, {
            method: 'POST', // or 'POST', 'PUT', etc.
            headers: headers,
            body: JSON.stringify({ 'property': property })
        })
            .then(response => response.json())
            .then(data => {

                $("#cmbAreas_con").empty();
                $('#cmbAreas_con').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.length; i++) {
                    $('#cmbAreas_con').append($('<option>', {
                        value: data[i].id,
                        text: data[i].nombre
                    }));
                }
            })
            .catch(error => console.error("Error fetching data: ", error));
    }
}
function loadTramos() {
    $("#cmbTramo option:not(:first)").remove();
    var property = $("#cmbDucto").val();
    const webMethod = 'tramos/fetch';
    url = apiUrl + webMethod;
    if (property) {

        fetch(url, {
            method: 'POST', // or 'POST', 'PUT', etc.
            headers: headers,
            body: JSON.stringify({ 'property': property })
        })
            .then(response => response.json())
            .then(data => {
                $("#cmbTramo").empty();
                $('#cmbTramo').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.length; i++) {
                    $('#cmbTramo').append($('<option>', {
                        value: data[i].id,
                        text: data[i].nombre
                    }));
                }
            })
            .catch(error => console.error("Error fetching data: ", error));
    }
    
}
function loadTramosCon() {
    $("#cmbTramo_con option:not(:first)").remove();
    var property = $("#cmbDucto_con").val();
    const webMethod = 'tramos/fetch';
    url = apiUrl + webMethod;
    if (property) {

        fetch(url, {
            method: 'POST', // or 'POST', 'PUT', etc.
            headers: headers,
            body: JSON.stringify({ 'property': property })
        })
            .then(response => response.json())
            .then(data => {
                $("#cmbTramo_con").empty();
                $('#cmbTramo_con').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.length; i++) {
                    $('#cmbTramo_con').append($('<option>', {
                        value: data[i].id,
                        text: data[i].nombre
                    }));
                }
            })
            .catch(error => console.error("Error fetching data: ", error));
    }

}
function inicializarEventos() {

    document.getElementById('filepruebabasecons').addEventListener('change', handleFileSelect, false);
    $(document).on("click", ".delete", function (e) {
        if(confirm("¿Seguro quiere borrar ese registro?")) {
         
        var webMethod = "";
        switch (temaconsulta) {
            case "T1":
                webMethod = "disenio_general/destroy";
                break;
            case "T2":
                webMethod = "disenio_presion/destroy";
                break;
            case "T3":
                webMethod = "disenio_proteccion/destroy";
                break;
            default:
        }
        var params = {
            id: e.currentTarget.dataset["id"] ,
        };
        $.ajax({
            type: "POST",
            url: apiUrl + webMethod,
            data: params,
            success: function (data) {
                alert("El registro fue eliminado correctamente");
                consulta();
            },
            error: function (xhr, ajaxOptions, thrownError) {

            }
        });  
    }   
    });
    $(document).on("click", ".edit", function (e) {
        var c = 0;
        $(this).parents("tr").find("td:not(:last-child)").each(function () {
            if (c === 0) {
                $(this).html('<input type="text" class="form-control" disabled value="' + $(this).text() + '">');
            } else {
                $(this).html('<input type="text" class="form-control" value="' + $(this).text() + '">');
            }
            c++;
        });
        $("#ra" + e.currentTarget.dataset["id"]).show();
        $("#re" + e.currentTarget.dataset["id"]).hide();
    });
    $(document).on("click", ".add", function (e) {
        var empty = false;
        
        var valores=[];
        var input = $(this).parents("tr").find('input[type="text"]');
        valores.push(e.currentTarget.dataset["id"]);
        input.each(function () {
            valores.push($(this).val());
           // alert($(this).val());
            if (!$(this).val()) {
                $(this).addClass("error");
                empty = true;
            } else {
                $(this).removeClass("error");
            }
        });
        $(this).parents("tr").find(".error").first().focus();
        if (!empty) {
            input.each(function () {
                $(this).parent("td").html($(this).val());
            });
            var webMethod = "";
            switch (temaconsulta) {
                case "T1":
                    webMethod = "disenio_general/update";
                    break;
                case "T2":
                    webMethod = "disenio_presion/update";
                    break;
                case "T3":
                    webMethod = "disenio_proteccion/update";
                    break;
                default:
            }
            var params = {               
            };
            switch (temaconsulta) {
                case "T1":
                    limpiarTabas();
                    $("#tablaPersonas > tbody").empty();
                    $("#tablaPersonas").show();
                    $("#tablapresion").hide();
                    $("#datapresioncons").hide();
                    $("#dataGeneral").show();
                    $("#tablaproteccion").hide();
                 break;
                case "T2":
                    limpiarTabas();               
                    $("#tablaPersonas").hide();
                    $("#tablapresion").show();
                    $("#datapresioncons").show();
                    $("#dataGeneral").hide();
                    $("#tablaproteccion").hide();
                break;
                case "T3":
                    limpiarTabas();
                    $("#datapresioncons").hide();
                    $("#dataGeneral").hide();
                    $("#tablaPersonas").hide();
                    $("#tablapresion").hide();
                    $("#tablaproteccion").show();
                break;
            }
            $.ajax({
                type: "POST",
                url: apiUrl + webMethod,
                data: params,
                success: function (data) {
                    alert("El registro fue actualizado correctamente");
                    consulta();
                },
                error: function (xhr, ajaxOptions, thrownError) {

                }
            });
            $("#ra" + e.currentTarget.dataset["id"]).hide();
            $("#re" + e.currentTarget.dataset["id"]).show();
        }
       
       
    });
   


    //Combo Ductos
    const selectDucto = document.getElementById('cmbDucto');
    selectDucto.addEventListener('change', function handleChange(event) {
        ducto = event.target.value;
        txtducto = event.target[event.target.selectedIndex].text;
        loadTramos(event.target.value);
    });
    //Combo Tramos
    const selectTramos = document.getElementById('cmbTramo');
    selectTramos.addEventListener('change', function handleChange(event) {
        tramo = event.target.value;
        txttramo = event.target[event.target.selectedIndex].text;
        loadAreas(event.target.value);
    });
    //Combo Areas
    const selectAreas = document.getElementById('cmbAreas');
    selectAreas.addEventListener('change', function handleChange(event) {
        area = event.target.value;
        txtarea = event.target[event.target.selectedIndex].text;
        kminicial = $('#cmbAreas option:selected').data('kminicial');
        kmfinal = $('#cmbAreas option:selected').data('kmfinal');
        kmorigen = $('#cmbAreas option:selected').data('kmorigen');
        kmdestino = $('#cmbAreas option:selected').data('kmdestino');
        $("#txtkminicial").val(kminicial);
        $("#txtkmfinal").val(kmfinal);
        $("#txtkmOrigen").val(kmorigen);
        $("#txtkmDestino").val(kmdestino);
    });
    $("#tablaPersonas tr").click(function () {

        $(".clickableRow").on("click", function () {
            $(".highlight").removeClass("highlight");
            $(this).addClass("highlight");

        });
    });
        //Combo Tramos Ducto
    const selectDuctoCon = document.getElementById('cmbDucto_con');
    selectDuctoCon.addEventListener('change', function handleChange(event) {
        ductocon = event.target.value;
        loadTramosCon(event.target.value);
    });
    //Combo Tramos Consulta
    const selectTramosCon = document.getElementById('cmbTramo_con');
    selectTramosCon.addEventListener('change', function handleChange(event) {
        tramocon = event.target.value;
        //loadAreasCon(event.target.value);
        loadSegmentosCon(event.target.value);
    });

    //Combo Segmento Consulta
    const selectSegmentoCon = document.getElementById('cmbSegmento_con');
    selectSegmentoCon.addEventListener('change', function handleChange(event) {
        tramocon = event.target.value;
        loadAreasCon(event.target.value);
    });

    //Combo Areas Consulta
    const selectAreasCon = document.getElementById('cmbAreas_con');
    selectAreasCon.addEventListener('change', function handleChange(event) {
        areaCon = event.target.value;
    });
    //Combo Temas
    const selectTemas = document.getElementById('cmbTemasPrincipal_con');
    selectTemas.addEventListener('change', function handleChange(event) {
        temaconsulta = event.target.value;
        switch (event.target.value) {
            case "T1":                
                $("#cmbTemasDisenio_con").show();
                $("#cmbTemasConstruccion_con").hide();
             break;
            case "T2":
                $("#cmbTemasDisenio_con").hide();
                $("#cmbTemasConstruccion_con").show()
            break;
            case "T3":
                //Aún no existe
            break;
            default:
        }
        tramo = event.target.value;
        txttramo = event.target[event.target.selectedIndex].text;
        loadAreas(event.target.value);
    });
    //Combo Tema Diseño
    const selectTemasDisenio = document.getElementById('cmbTemasDisenio_con');
    selectTemasDisenio.addEventListener('change', function handleChange(event) {
        temaconsultadisenio = event.target.value;
        switch (event.target.value) {
            case "Dis1":
                limpiarTabas();
                OcultarConstruccionConsulta();
            $("#tablaPersonas > tbody").empty();
            $("#tablaPersonas").show();
            $("#tablapresion").hide();
            $("#datapresioncons").hide();
            $("#dataGeneral").show();
            $("#tablaproteccion").hide();
            break;
            case "Dis2":
                limpiarTabas();
                OcultarConstruccionConsulta();
            $("#tablaPersonas").hide();
            $("#tablapresion").show();
            $("#datapresioncons").show();
            $("#dataGeneral").hide();
            $("#tablaproteccion").hide();
            break;
            case "Dis3":
                limpiarTabas();
                OcultarConstruccionConsulta();
            $("#datapresioncons").hide();
            $("#dataGeneral").hide();
            $("#tablaPersonas").hide();
            $("#tablapresion").hide();
            $("#tablaproteccion").show();
            break;
        default:
    }
        tramo = event.target.value;
        txttramo = event.target[event.target.selectedIndex].text;
        loadAreas(event.target.value);
    });
    //Combo Tema Diseño
    const selectTemasConstruccion = document.getElementById('cmbTemasConstruccion_con');
    selectTemasConstruccion.addEventListener('change', function handleChange(event) {
        temaconsultaconstruccion = event.target.value;
        switch (event.target.value) {
            case "Cons1":
                ocultartablasdisenio();
                $("#tablabasecons").show();
                $("#databasegeneral").show();
                $("#tablaunionCons").hide();
                $("#tablaProfundidad").hide();
                $("#tablaConsCruces").hide();
                $("#tablaHermeticidad").hide();
                $("#tablaConsCatodica").hide();
                $("#datacatodica").hide();
                break;
            case "Cons2":
                ocultartablasdisenio();
                $("#tablaunionCons").show();
                $("#tablabasecons").hide();
                $("#databasegeneral").hide();
                $("#tablaProfundidad").hide();
                $("#tablaConsCruces").hide();
                $("#tablaHermeticidad").hide();
                $("#tablaConsCatodica").hide();
                $("#datacatodica").hide();
                break;
            case "Cons3":
                ocultartablasdisenio();
                $("#tablaProfundidad").show();
                $("#tablaunionCons").hide();
                $("#tablabasecons").hide();
                $("#databasegeneral").hide();
                $("#tablaConsCruces").hide();
                $("#tablaHermeticidad").hide();
                $("#tablaConsCatodica").hide();
                $("#datacatodica").hide();
                break;
            case "Cons4":
                ocultartablasdisenio();
                $("#tablaConsCruces").show();
                $("#tablaProfundidad").hide();
                $("#tablaunionCons").hide();
                $("#tablabasecons").hide();
                $("#databasegeneral").hide();
                $("#tablaHermeticidad").hide();
                $("#tablaConsCatodica").hide();
                break;
            case "Cons5":
                ocultartablasdisenio();
                $("#tablaHermeticidad").show();
                $("#tablaConsCruces").hide();
                $("#tablaProfundidad").hide();
                $("#tablaunionCons").hide();
                $("#tablabasecons").hide();
                $("#databasegeneral").hide();
                $("#tablaConsCatodica").hide();
                break;
            case "Cons6":

                break;
            case "Cons7":
                ocultartablasdisenio();
                $("#tablaConsCatodica").show();
                $("#datacatodica").show();
                $("#tablaHermeticidad").hide();
                $("#tablaConsCruces").hide();
                $("#tablaProfundidad").hide();
                $("#tablaunionCons").hide();
                $("#tablabasecons").hide();
                $("#databasegeneral").hide();
                break;
            case "Cons8":

                break;
            default:
        }
    });
    //switch (event.target.value) {
    //    case "T1":
    //        limpiarTabas();
    //        $("#tablaPersonas > tbody").empty();
    //        $("#tablaPersonas").show();
    //        $("#tablapresion").hide();
    //        $("#datapresioncons").hide();
    //        $("#dataGeneral").show();
    //        $("#tablaproteccion").hide();
    //        break;
    //    case "T2":
    //        limpiarTabas();
    //        $("#tablaPersonas").hide();
    //        $("#tablapresion").show();
    //        $("#datapresioncons").show();
    //        $("#dataGeneral").hide();
    //        $("#tablaproteccion").hide();
    //        break;
    //    case "T3":
    //        limpiarTabas();
    //        $("#datapresioncons").hide();
    //        $("#dataGeneral").hide();
    //        $("#tablaPersonas").hide();
    //        $("#tablapresion").hide();
    //        $("#tablaproteccion").show();
    //        break;
    //    default:
    //}

    //Combo seleccionar Tipo de cruce
    //const selectTipoCruce = document.getElementById('cmbTipcruce');
    //selectTipoCruce.addEventListener('change', function handleChange(event) {
    //    var tipocruce = event.target.value;
    //    switch (tipocruce) {
    //        case "A":
    //            $("#att_llanurainundacion").show();
    //            $("#att_tipocrucehidro").show();
    //            $("#att_transportepesado").hide();
    //            $("#att_gasoductopatrullado").hide();
    //            $("#att_vialidadabierta").hide();
    //            $("#att_carrilesvialidad").hide();
    //            $("#att_edohistodos").hide();
    //            $("#att_edoactualdos").hide();
    //            $("#att_tipocrucetrnasporte").hide();
    //            $("#att_existeunioncables").hide();
    //            $("#att_ultimopotencialapago").hide();
    //            $("#att_ultimopontencialencendio").hide();
    //            $("#att_rectuberiaextranjera").hide();
    //            $("#att_diametronom").hide();
    //            $("#att_tipotuberia").hide();
    //            $("#att_existecruceytuberia").hide();
    //            $("#att_tipocruceservicio").hide();
    //            $("#att_voltajetransportadoporservicio").hide();
    //            break;
    //        case "C":
    //            $("#att_llanurainundacion").hide();
    //            $("#att_tipocrucehidro").hide();
    //            $("#att_transportepesado").show();
    //            $("#att_gasoductopatrullado").show();
    //            $("#att_vialidadabierta").show();
    //            $("#att_carrilesvialidad").show();
    //            $("#att_edohistodos").show();
    //            $("#att_edoactualdos").show();
    //            $("#att_tipocrucetrnasporte").show();
    //            $("#att_existeunioncables").hide();
    //            $("#att_ultimopotencialapago").hide();
    //            $("#att_ultimopontencialencendio").hide();
    //            $("#att_rectuberiaextranjera").hide();
    //            $("#att_diametronom").hide();
    //            $("#att_tipotuberia").hide();
    //            $("#att_existecruceytuberia").hide();
    //            $("#att_tipocruceservicio").hide();
    //            $("#att_voltajetransportadoporservicio").hide();
    //            break;
    //        case "E":
    //            $("#att_llanurainundacion").hide();
    //            $("#att_tipocrucehidro").hide();
    //            $("#att_transportepesado").hide();
    //            $("#att_gasoductopatrullado").hide();
    //            $("#att_vialidadabierta").hide();
    //            $("#att_carrilesvialidad").hide();
    //            $("#att_edohistodos").hide();
    //            $("#att_edoactualdos").hide();
    //            $("#att_tipocrucetrnasporte").hide();
    //            $("#att_existeunioncables").show();
    //            $("#att_ultimopotencialapago").show();
    //            $("#att_ultimopontencialencendio").show();
    //            $("#att_rectuberiaextranjera").show();
    //            $("#att_diametronom").show();
    //            $("#att_tipotuberia").show();
    //            $("#att_existecruceytuberia").hide();
    //            $("#att_tipocruceservicio").hide();
    //            $("#att_voltajetransportadoporservicio").hide();
    //            break
    //        case "S":
    //            $("#att_llanurainundacion").hide();
    //            $("#att_tipocrucehidro").hide();
    //            $("#att_transportepesado").hide();
    //            $("#att_gasoductopatrullado").hide();
    //            $("#att_vialidadabierta").hide();
    //            $("#att_carrilesvialidad").hide();
    //            $("#att_edohistodos").hide();
    //            $("#att_edoactualdos").hide();
    //            $("#att_tipocrucetrnasporte").hide();
    //            $("#att_existeunioncables").hide();
    //            $("#att_ultimopotencialapago").hide();
    //            $("#att_ultimopontencialencendio").hide();
    //            $("#att_rectuberiaextranjera").hide();
    //            $("#att_diametronom").hide();
    //            $("#att_tipotuberia").hide();
    //            $("#att_existecruceytuberia").show();
    //            $("#att_tipocruceservicio").show();
    //            $("#att_voltajetransportadoporservicio").show();
    //            break;
    //        default:
    //    }
    //});
}
function ocultartablasdisenio() {
    $("#tablaPersonas").hide();
    $("#tablapresion").hide();
    $("#datapresioncons").hide();
    $("#dataGeneral").hide();
    $("#tablaproteccion").hide();
}

function handleFileSelect(evt) {
    var f = evt.target.files[0]; // FileList object
    var reader = new FileReader();
    // Closure to capture the file information.
    reader.onload = (function (theFile) {
        return function (e) {
            var binaryData = e.target.result;
            //Converting Binary Data to base 64
            var base64String = window.btoa(binaryData);
            docbasecons = base64String;
            //showing file converted to base64
            //document.getElementById('base64').value = base64String;
            //alert('File converted to base64 successfuly!\nCheck in Textarea');
        };
    })(f);
    // Read in the image file as a data URL.
    reader.readAsBinaryString(f);
}
function limpiarTabas() {
    var table0 = document.getElementById('tablapresion');
    var rowCount0 = table0.rows.length;
    for (var i = rowCount0; i > 1; --i) {
        table0.deleteRow(i - 1);
    }
    var table2 = document.getElementById('tablapresion');
    var rowCount2 = table2.rows.length;
    for (var c = rowCount2; c > 1; --c) {
        table2.deleteRow(c - 1);
    }
    var table3 = document.getElementById('tablaPersonas');
    var rowCount3 = table3.rows.length;
    for (var h = rowCount3; h > 1; --h) {
        table3.deleteRow(h - 1);
    }
}
function ezBSAlert(options) {
    var deferredObject = $.Deferred();
    var defaults = {
        type: "alert", //alert, prompt,confirm 
        modalSize: 'modal-sm', //modal-sm, modal-lg
        okButtonText: 'Ok',
        cancelButtonText: 'Cancel',
        yesButtonText: 'Yes',
        noButtonText: 'No',
        headerText: 'Attention',
        messageText: 'Message',
        alertType: 'default', //default, primary, success, info, warning, danger
        inputFieldType: 'text', //could ask for number,email,etc
    }
    $.extend(defaults, options);

    var _show = function () {
        var headClass = "navbar-default";
        switch (defaults.alertType) {
            case "primary":
                headClass = "alert-primary";
                break;
            case "success":
                headClass = "alert-success";
                break;
            case "info":
                headClass = "alert-info";
                break;
            case "warning":
                headClass = "alert-warning";
                break;
            case "danger":
                headClass = "alert-danger";
                break;
        }
        $('BODY').append(
            '<div id="ezAlerts" class="modal fade">' +
            '<div class="modal-dialog" class="' + defaults.modalSize + '">' +
            '<div class="modal-content">' +
            '<div id="ezAlerts-header" class="modal-header ' + headClass + '">' +
            '<button id="close-button" type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>' +
            '<h4 id="ezAlerts-title" class="modal-title">Modal title</h4>' +
            '</div>' +
            '<div id="ezAlerts-body" class="modal-body">' +
            '<div id="ezAlerts-message" ></div>' +
            '</div>' +
            '<div id="ezAlerts-footer" class="modal-footer">' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>'
        );

        $('.modal-header').css({
            'padding': '15px 15px',
            '-webkit-border-top-left-radius': '5px',
            '-webkit-border-top-right-radius': '5px',
            '-moz-border-radius-topleft': '5px',
            '-moz-border-radius-topright': '5px',
            'border-top-left-radius': '5px',
            'border-top-right-radius': '5px'
        });

        $('#ezAlerts-title').text(defaults.headerText);
        $('#ezAlerts-message').html(defaults.messageText);

        var keyb = "false", backd = "static";
        var calbackParam = "";
        switch (defaults.type) {
            case 'alert':
                keyb = "true";
                backd = "true";
                $('#ezAlerts-footer').html('<button class="btn btn-' + defaults.alertType + '">' + defaults.okButtonText + '</button>').on('click', ".btn", function () {
                    calbackParam = true;
                    $('#ezAlerts').modal('hide');
                });
                break;
            case 'confirm':
                var btnhtml = '<button id="ezok-btn" class="btn btn-primary">' + defaults.yesButtonText + '</button>';
                if (defaults.noButtonText && defaults.noButtonText.length > 0) {
                    btnhtml += '<button id="ezclose-btn" class="btn btn-default">' + defaults.noButtonText + '</button>';
                }
                $('#ezAlerts-footer').html(btnhtml).on('click', 'button', function (e) {
                    if (e.target.id === 'ezok-btn') {
                        calbackParam = true;
                        $('#ezAlerts').modal('hide');
                    } else if (e.target.id === 'ezclose-btn') {
                        calbackParam = false;
                        $('#ezAlerts').modal('hide');
                    }
                });
                break;
            case 'prompt':
                $('#ezAlerts-message').html(defaults.messageText + '<br /><br /><div class="form-group"><input type="' + defaults.inputFieldType + '" class="form-control" id="prompt" /></div>');
                $('#ezAlerts-footer').html('<button class="btn btn-primary">' + defaults.okButtonText + '</button>').on('click', ".btn", function () {
                    calbackParam = $('#prompt').val();
                    $('#ezAlerts').modal('hide');
                });
                break;
        }

        $('#ezAlerts').modal({
            show: false,
            backdrop: backd,
            keyboard: keyb
        }).on('hidden.bs.modal', function (e) {
            $('#ezAlerts').remove();
            deferredObject.resolve(calbackParam);
        }).on('shown.bs.modal', function (e) {
            if ($('#prompt').length > 0) {
                $('#prompt').focus();
            }
        }).modal('show');
    }

    _show();
    return deferredObject.promise();
}

function fnFinalizar() {
    document.getElementById('registro').style.display = 'none';
    document.getElementById('forms').style.display = 'block';
   
    //$('#forms').show();
    //$('#registro').hide();
   
}

//#region FORMULARIOS DISEÑO
function fnshowIndentificacion() {
    $('#identificacionfrm').show();
    $('#disenioforms').hide();
    loadtipocostura();
    loadtipomaterialdisenio();
}
function fnshowServicio() {
    $('#serviciofrm').show();
    $('#disenioforms').hide();
}
function fnshowPresion() {
    $('#presionfrm').show();
    $('#disenioforms').hide();
}
function fnshowProteccion() {
    $('#proteccionfrm').show();
    $('#disenioforms').hide();
}
function fnshowdisenioforms() {
    $('#disenioforms').show();
    $('#forms').hide();
    $("#txtductogeneral").val(txtducto);
    $("#txttramogeneral").val(txttramo);
    $("#txtareageneral").val(txtarea);
    $("#txtductopresion").val(txtducto);
    $("#txttramopresion").val(txttramo);
    $("#txtareapresion").val(txtarea);
    $("#txtductoproteccion").val(txtducto);
    $("#txttramoproteccion").val(txttramo);
    $("#txtareaproteccion").val(txtarea);
    $("#txtductoservicio").val(txtducto);
    $("#txttramoservicio").val(txttramo);
    $("#txtareaservicio").val(txtarea);
}
//#endregion 
//#region FORMULARIOS NAGEVACIÓN CONSTRUCCIÓN
function fnsshowconstruforms() {
    $('#construforms').show();
    $('#forms').hide();

}
function fnshowmetunion() {
    $('#metodounionfrm').show();
    $('#construforms').hide();
    $("#txtductogeneralunion").val(txtducto);
    $("#txttramogeneralunion").val(txttramo);
    $("#txtareageneralunion ").val(txtarea);
    loadtipotecnica();
    loadtipoubicacion();

}
function fnshowprofenterrado() {
    $('#profenterradofrm').show();
    $('#construforms').hide();
    $("#txtductogeneralprofent").val(txtducto);
    $("#txttramogeneralprofent").val(txttramo);
    $("#txtareageneralprofent ").val(txtarea);
}
function fnshowprotipocruces() {
    $('#tiposcrucesfrm').show();
    $('#construforms').hide();
    $("#txtductogeneraltipcruce").val(txtducto);
    $("#txttramogeneraltipocruce").val(txttramo);
    $("#txtareageneralptipocruce ").val(txtarea);
    loadCmbCruceServicio();
    loadCmbCruceTuberia();
    loadCmbCruceTransporte();
}
function fnshowhermeti() {
    $('#hermetisidadfrm').show();
    $('#construforms').hide();
    $("#txtductogeneralherm").val(txtducto);
    $("#txttramogeneralherm").val(txttramo);
    $("#txtareageneralherm ").val(txtarea);
}
function fnshowreporteinsp() {
    $('#reportesInspeccionfrm').show();
    $('#construforms').hide();
    $("#txtductogeneralrep").val(txtducto);
    $("#txttramogeneralrep").val(txttramo);
    $("#txtareageneralrep ").val(txtarea);
}
function fnshowprotecccato() {
    $('#proteccatodicafrm').show();
    $('#construforms').hide();
    $("#txtductogeneralprot").val(txtducto);
    $("#txttramogeneralprot").val(txttramo);
    $("#txtareageneralprot ").val(txtarea);
    
    loadtipoproteccioncatodica();
    loadtipoinstalacion();
}
function fnshowseguridadpre() {
    $('#seguridadprearranquefrm').show();
    $('#construforms').hide();
    $("#txtductogeneralseg").val(txtducto);
    $("#txttramogeneralseg").val(txttramo);
    $("#txtareageneralseg ").val(txtarea);
}
function fnshowbaseconst() {
    $('#constbasefrm').show();
    $('#construforms').hide();
    $("#txtductogeneralbasecons").val(txtducto);
    $("#txttramogeneralbasecons").val(txttramo);
    $("#txtareageneralbasecons").val(txtarea);
}
function cancelbasecons() {
    $('#constbasefrm').hide();
    $('#construforms').show();
}
function cancelunion() {
    $('#metodounionfrm').hide();
    $('#construforms').show();
}
function fncancelprofenterrado() {
    $('#profenterradofrm').hide();
    $('#construforms').show();
}
function fncanceltipocruces() {
    $('#tiposcrucesfrm').hide();
    $('#construforms').show();
}
function cancelherme() {
    $('#hermetisidadfrm').hide();
    $('#construforms').show();
}
function cancelreporteinsp() {
    $('#reportesInspeccionfrm').hide();
    $('#construforms').show();
}
function cancelprotcato() {
    $('#proteccatodicafrm').hide();
    $('#construforms').show();
}
function cancelseguridadpre() {
    $('#seguridadprearranquefrm').hide();
    $('#construforms').show();
}
function reiniciarFormsConstruccion() {
    $('#registro').show();
    $('#forms').hide();
    $('#step-1').show();
    $('#step-2').hide();
    $('#step-3').hide();
    $('#construforms').hide();
    loadDuctos();
    $("#cmbTramo").empty();
    $('#cmbTramo').append($('<option>', {
        value: 0,
        text: 'Selecciona...'
    }));
    $("#cmbAreas").empty();
    $('#cmbAreas').append($('<option>', {
        value: 0,
        text: 'Selecciona...'
    }));
}
//#endregion
//#region Construcción 

//function savebasecons() {
//    var webMethod = "saveConstruccionGeneral";
//    if ($("#coord_esp_idenbasecons").val() !== "") {
//        const formData = new FormData();

//        formData.append("C_0101_0001_id", area)
//        // Make sure files are being selected and appended properly
//        if ($("#inputGroupFile01")[0].files[0]) {
//            formData.append("C_0308_0111", $("#filepruebabasecons")[0].files[0]);
//        }
//        // Log formData to console for debugging (this will not display the content of the files)
//        for (var pair of formData.entries()) {
//            console.log(pair[0] + ', ' + pair[1]);
//        }
//        var params = {
//            C_0101_0001_id: area,
//            C_0301_0048: $("#fechaconstbase").val(),
//            C_0306_0108: $("#metrecubbase").val(),
//            C_0307_0109: $("#txttiposuelobaseconst").val(),
//            C_0307_0110: $("#txtmatrellenobaseconst").val(),
//            C_0308_0110: $("#presionhermebasecons").val(),
//            file: formData,
//            C_0308_0111: $("#cmtipotecnicaunion").val(),
//            coordenada_especifica: $("#coord_esp_idenbasecons").val(),
//            kilometro_especifico: $("#km_esp_idenbasecons").val()
//        };
//        console.log(JSON.stringify(params))
//        fetch(apiUrl + webMethod, {
//            method: 'POST',
//            headers: headers,
//            body: JSON.stringify(params)
//        })
//            .then(response => {
//                if (!response.ok) {
//                    throw new Error('Network response was not ok');
//                }
//                console.log(response)
//                return response.json();

//            })
//            .then(data => {
//                if (data.success) {
//                    console.log(data.data);
//                    alert("Información almacenada correctamente");
//                    $('#construforms').show();
//                    $('#constbasefrm').hide();
//                }
//            })
//            .catch(error => {
//                alert("Error: " + error);
//            });
//    }
//    else {
//        alert("Es necesario ingresar el diámetro en pulgadas para realizar el registro");
//    }
//}
function saveConstruccionGeneral() {

    var webMethod = "disenio_servicio/store";

    const formData = new FormData();
    formData.append("C_0101_0001_id", area)
    // Make sure files are being selected and appended properly
    if ($("#inputGroupFile01")[0].files[0]) {
        formData.append("C_0205_0012", $("#inputGroupFile01")[0].files[0]);
    }
    if ($("#inputGroupFile02")[0].files[0]) {
        formData.append("C_0205_0013", $("#inputGroupFile02")[0].files[0]);
    }
    if ($("#inputGroupFile03")[0].files[0]) {
        formData.append("C_0205_0014", $("#inputGroupFile03")[0].files[0]);
    }
    if ($("#inputGroupFile04")[0].files[0]) {
        formData.append("C_0205_0015", $("#inputGroupFile04")[0].files[0]);
    }
    if ($("#inputGroupFile05")[0].files[0]) {
        formData.append("C_0205_0016", $("#inputGroupFile05")[0].files[0]);
    }

    // Log formData to console for debugging (this will not display the content of the files)
    for (var pair of formData.entries()) {
        console.log(pair[0] + ', ' + pair[1]);
    }






    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: {
            'Accept': 'application/json'
        },
        body: formData
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();

        })
        .then(data => {
            console.log(typeof data)
            console.log(data)
            if (data.success) {
                console.log(data)
                alert("Información almacenada correctamente");
                $('#disenioforms').show();
                $('#serviciofrm').hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}
function saveConstruccionUnion() {

    var webMethod = "saveConstruccionUnion";

    var params = {
        C_0101_0001_id: area,
        C_0302_0049_id: $("#cmtipotecnicaunion").val(),
        C_0302_0050: $("#txtidentificadorunion").val(),
        C_0302_0051: $("#txtrecaplsolunion").val(),
        C_0302_0052: $("#fechaserunion").val(),
        C_0302_0053: $("#fecinstunion").val(),
        C_0302_0054_id: $("#cmbmetubicsoldunion").val(),
        C_0302_0055: $("#fecfabunion").val(),
        C_0302_0056: $("#txtedoactunion").val(),
        C_0302_0057: $("#txtedohisunion").val(),
        coordenada_especifica: $("#coord_esp_idenunion").val(),
        kilometro_especifico: $("#km_esp_idenunion").val()
    };



    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();

        })
        .then(data => {
            console.log(typeof data)
            console.log(data)
            if (data.success) {
                console.log(data)
                alert("Información almacenada correctamente");
                $('#construforms').show();
                $('#metodounionfrm').hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}
function saveConstruccionProfundidad() {

    var webMethod = "saveConstruccionProfundidad";

    var params = {
        C_0101_0001_id: area,
        C_0303_0058: $("#txtprofcob").val(),
        C_0303_0059: $("#txtmedprofagu").val(),
        C_0303_0060: $("#txtelefontub").val(),
        C_0303_0061: $("#txtelecentub").val(),
        C_0303_0062: $("#txteleterr").val(),
        C_0303_0063: $("#txteleparsuotub").val(),
        C_0303_0064: $("#txtdistinicioruta").val(),
        C_0303_0065: $("#fechamedidaprof").val(),
        C_0303_0066: $("#txtperdirhor").val(),
        C_0303_0067: $("#txtmetmedprof").val(),
        C_0303_0068: $("#txtedoactprof").val(),
        C_0303_0069: $("#txtedohisprof").val(),
        coordenada_especifica: $("#coord_esp_idenprofent").val(),
        kilometro_especifico: $("#km_esp_idenpprofent").val()
    };


    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();

        })
        .then(data => {
            console.log(typeof data)
            console.log(data)
            if (data.success) {
                console.log(data)
                alert("Información almacenada correctamente");
                $('#construforms').show();
                $('#profenterradofrm').hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}
function saveConstruccionCruces() {

    var webMethod = "saveConstruccionCruces";

    var params = {
        C_0101_0001_id: area,
        C_0304_0070_id: $("#cmbTipcruce").val(),//Tipod de cruce
        C_0304_0071: $("#txtclaseloca").val(),//Clase de Localización

        C_0304_0072: $("#txtpropietario").val(),//Propietario

        C_0304_0073: $("#txtdictacruce").val(), //Distancia del cruce encima o debajo de la tubería

        C_0304_0074: $("#txtdistinf").val(),// Distancia desde el punto de cruce influye en la dirección aguas abajo

        C_0304_0075: $("#txtdistptocruce").val,//Distancia desde el punto de cruce influye en la dirección aguas arriba

        C_0304_0076: $("#txtloccruresptub").val(),//Localización del cruce respecto la tubería (arriba/abajo)

        C_0304_0077: $("#txtedoactualcruce").val(),//Estado Actual

        C_0304_0078: $("#txtedohistcruce").val(),//Estado histórico

        C_0304_0079: $("#txttipllanurainun").val(),//Tipo de llanura de inundación
        C_0304_0080: $("#txttipcrucehidro").val(),//Tipo de cruce hidrológico
        C_0304_0081: $("#cmbtipcamtrans").val(),//Indica si el camino es de transporte pesado

        C_0304_0082: $("#cmbgasnecpat").val(),// El gasoducto necesita ser patrullado

        C_0304_0083: $("#txtvialidadabierta").val(),//No. de Carrilles de la vialidad-

        C_0304_0084: $("#txtNumCarrillesVialidad").val(), //Estado histórico

        C_0304_0085: $("#txtEdohistoricoCrucedos").val(),//Estado actual

        C_0304_0086: $("#txtEdoActualCrucedos").val(),//Tipo de cruce de transporte

        C_0304_0087_id: $("#cmbetipocrucetrans").val(), //¿Existe unión de cables?

        C_0304_0088: $("#cmbexiunicab").val(),//¿Existe unión de cables? (si, no, desconocido)


        C_0304_0089: $("#txtultpottubapago").val(),//Último potencial de tubería a tierra medido (expresado en voltios) se apag+o

        C_0304_0090: $("#txtultpotencen").val(),//Último potencial de tubería a tierra medido (expresado en voltios) se encendió

        C_0304_0091: $("#txtrectubext").val(),// Recubrimiento de tubería extranjera
        C_0304_0092: $("#txtdiamnomtub").val(),//Diámetro nominal tubería extranjera

        C_0304_0093_id: $("#cmntiptub").val(),//Tipo de tuberia
        C_0304_0094: $("#cmbexisunioncabcruceytub").val(),//¿Existe unión de cables entre el servicio de cruce y la tubería?
        C_0304_0095_id: $("#cmbtipcruceserv").val(),//Tipo de cruce de servicio
        C_0304_0096: $("#txtvoltajecruce").val,// Voltaje transportado por el servicio
        coordenada_especifica: $("#coord_esp_identipocruce").val(),
        kilometro_especifico: $("#km_esp_idenptipocruce").val()
    };

    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();

        })
        .then(data => {
            console.log(typeof data)
            console.log(data)
            if (data.success) {
                console.log(data)
                alert("Información almacenada correctamente");
                $('#construforms').show();
                $('#tiposcrucesfrm').hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}
function saveConstruccionHermeticidad() {

    var webMethod = "saveConstruccionHermeticidad";

    var params = {
        C_0101_0001_id: area,
        C_0305_0097: $("#txtnombempher").val(),//Nombre de la empresa
        C_0305_0098: $("#fecpruebher").val(),//Fecha de prueba
        C_0305_0099: $("#txtdurpruebher").val(),//Duración de la prueba
        C_0305_0100: $("#txtmedempher").val(),//Medio de prueba de empleo
        C_0305_0101: $("#txtlongducprobados").val(),//Longitud de los ductos probados
        C_0305_0102: $("#txtpresprueb").val(),//Presión de diseño
        C_0305_0103: $("#txtpresdisger").val(),//Calibración
        C_0305_0104: $("#txtcalbher").val(),//Variaciones de presión
        C_0305_0105: $("#txtvarher").val(),//Presión de prueba mínima
        C_0305_0106: $("#txtvarpreher").val(),//Variaciones de presión
        coordenada_especifica: $("#coord_esp_idenherm").val(),
        kilometro_especifico: $("#km_esp_idenpherm").val(),
        unidad_presion_max: $("#cmbunidadpresionmax").val(),
        unidad_presion_disenio: $("#cmbunidadpresiondisenio").val(),
        unidad_presion_min: $("#cmbunidadpresionmin").val(),
        unidad_variaciones_presion: $("#cmbunidadvariacionespres").val()
    };



    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();

        })
        .then(data => {
            console.log(typeof data)
            console.log(data)
            if (data.success) {
                console.log(data)
                alert("Información almacenada correctamente");
                $('#construforms').show();
                $('#hermetisidadfrm').hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}
function saveConstruccioInspeccion() {

    var webMethod = "disenio_servicio/store";

    var params = {
        C_0101_0001_id: area,
        C_0302_0049_id: $("#cmtipotecnicaunion").val(),
        C_0302_0050: $("#txtidentificadorunion").val(),
        C_0302_0051: $("#txtrecaplsolunion").val(),
        C_0302_0052: $("#fechaserunion").val(),
        C_0302_0053: $("#fecinstunion").val(),
        C_0302_0054_id: $("#cmbmetubicsoldunion").val(),
        C_0302_0055: $("#fecfabunion").val(),
        C_0302_0056: $("#txtedoactunion").val(),
        C_0302_0057: $("#txtedohisunion").val(),
        coordenada_especifica: $("#coord_esp_idenunion").val(),
        kilometro_especifico: $("#km_esp_idenunion").val()
    };



    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: {
            'Accept': 'application/json'
        },
        body: formData
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();

        })
        .then(data => {
            console.log(typeof data)
            console.log(data)
            if (data.success) {
                console.log(data)
                alert("Información almacenada correctamente");
                $('#disenioforms').show();
                $('#serviciofrm').hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}
function saveConstruccioCatodica() {

    var webMethod = "saveConstruccionCatodica";

    var params = {
        C_0101_0001_id: area,
        C_0310_116_id: $("#cmbTipocato").val(),
        C_0310_117_id: $("#cmbtipinstprot").val(),
        nombre: $("#txtnombrecatodica").val(),
        C_0310_118: $("#txtnoserie").val(),
        C_0310_119: $("#txtfabricante").val(),
        C_0310_120: $("#extedoprote").val(),
        coordenada_especifica: $("#coord_esp_idenprot").val(),
        kilometro_especifico: $("#km_esp_idenpprot").val()
    };




    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();

        })
        .then(data => {
            console.log(typeof data)
            console.log(data)
            if (data.success) {
                console.log(data)
                alert("Información almacenada correctamente");
                $('#construforms').show();
                $('#proteccatodicafrm').hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}
function saveConstruccioSeguridad() {

    var webMethod = "disenio_servicio/store";

    var params = {
        C_0101_0001_id: area,
        C_0302_0049_id: $("#cmtipotecnicaunion").val(),
        C_0302_0050: $("#txtidentificadorunion").val(),
        C_0302_0051: $("#txtrecaplsolunion").val(),
        C_0302_0052: $("#fechaserunion").val(),
        C_0302_0053: $("#fecinstunion").val(),
        C_0302_0054_id: $("#cmbmetubicsoldunion").val(),
        C_0302_0055: $("#fecfabunion").val(),
        C_0302_0056: $("#txtedoactunion").val(),
        C_0302_0057: $("#txtedohisunion").val(),
        coordenada_especifica: $("#coord_esp_idenunion").val(),
        kilometro_especifico: $("#km_esp_idenunion").val()
    };



    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: {
            'Accept': 'application/json'
        },
        body: formData
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();

        })
        .then(data => {
            console.log(typeof data)
            console.log(data)
            if (data.success) {
                console.log(data)
                alert("Información almacenada correctamente");
                $('#disenioforms').show();
                $('#serviciofrm').hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}
function cancelotroCruceServicio() {
    $("#espcruceServicio").hide();
}
function saveotroCruceServicio() {
    var webMethod = "saveCruceServicio";
    var params = {
        C_0304_0095: $("#newCruceServicio").val(),
        descripcion: $("#newDescTipoServicio").val()
    };


    console.log(JSON.stringify(params))
    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            console.log(response)
            return response.json();

        })
        .then(data => {
            if (data.success) {
                console.log(data.data);
                alert("Información almacenada correctamente");
                loadCmbCruceServicio();
                $("#espcruceServicio").hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}
function showotroCruceServicio() {
    $('#espcruceServicio').show();
}
function loadCmbCruceServicio() {
    var webMethod = "get_CruceServicioCons";
    $.ajax({
        type: "GET",
        url: apiUrl + webMethod,
        success: function (data) {
            if (data.success) {
                console.log(data.data);
                $("#cmbtipcruceserv").empty();
                $('#cmbtipcruceserv').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.data.length; i++) {
                    $('#cmbtipcruceserv').append($('<option>', {
                        value: data.data[i].id,
                        text: data.data[i].C_0304_0095
                    }));
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {

        }
    });
}


function cancelotroTuberiaCruce() {
    $("#espcruceTuberia").hide();
}
function showotroCruceTuberia() {
    $('#espcruceTuberia').show();
}
function saveotroCruceTuberia() {
    var webMethod = "saveTuberiaCons";
    var params = {
        C_0304_0093: $("#newCruceTuberia").val(),
        descripcion: $("#newDescCruceTuberia").val()
    };


    console.log(JSON.stringify(params))
    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            console.log(response)
            return response.json();

        })
        .then(data => {
            if (data.success) {
                console.log(data.data);
                alert("Información almacenada correctamente");
                loadCmbCruceTuberia();
                $("#espcruceTuberia").hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}
function loadCmbCruceTuberia() {
    var webMethod = "get_Tuberia";
    $.ajax({
        type: "GET",
        url: apiUrl + webMethod,
        success: function (data) {
            if (data.success) {
                console.log(data.data);
                $("#cmntiptub").empty();
                $('#cmntiptub').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.data.length; i++) {
                    $('#cmntiptub').append($('<option>', {
                        value: data.data[i].id,
                        text: data.data[i].C_0304_0093
                    }));
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {

        }
    });
}


function cancelotroTransporteCruce() {
    $("#espcruceTransporte").hide();
}


function creartipotecnicaunion() {
    $("#espcruceTransporte").hide();
}


function showotroCruceTransporte() {
    $('#espcruceTransporte').show();
}
function saveotroCruceTransporte() {
    var webMethod = "saveCruceTransporte";
    var params = {
        C_0304_0087: $("#newCruceTransporte").val(),
        descripcion: $("#newDescTipoTransporte").val()
    };


    console.log(JSON.stringify(params))
    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            console.log(response)
            return response.json();

        })
        .then(data => {
            if (data.success) {
                console.log(data.data);
                alert("Información almacenada correctamente");
                loadCmbCruceTransporte();
                $("#espcruceTransporte").hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}
function loadCmbCruceTransporte() {
    var webMethod = "get_CruceTransporteCons";
    $.ajax({
        type: "GET",
        url: apiUrl + webMethod,
        success: function (data) {
            if (data.success) {
                console.log(data.data);
                $("#cmbetipocrucetrans").empty();
                $('#cmbetipocrucetrans').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.data.length; i++) {
                    $('#cmbetipocrucetrans').append($('<option>', {
                        value: data.data[i].id,
                        text: data.data[i].C_0304_0087
                    }));
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {

        }
    });
}




//#endregion
function selectTab(evt, tabName) {
    // Declare all variables

    var i, tabcontent, tablinks;

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("nav-item");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    // Show the current tab, and add an "active" class to the link that opened the tab
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
    document.getElementById("Contenido").style.display = "block";
    if (tabName === 'Opcion1') {
        console.log(tabName)
        loadDuctos();
       
    }

    
}
function loadtipocostura() {
    var webMethod = "get_tipocostura";
    $.ajax({
        type: "GET",
        url: apiUrl + webMethod,
        success: function (data) {
            if (data.success) {
                console.log(data.data);
                $("#cmbTipoCostura").empty();
                $('#cmbTipoCostura').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.data.length; i++) {
                    $('#cmbTipoCostura').append($('<option>', {
                        value: data.data[i].id,
                        text: data.data[i].C_0208_0029
                    }));
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {

        }
    });
}
function loadtipomaterialdisenio() {
    var webMethod = "get_tipomaterialdisenio";
    $.ajax({
        type: "GET",
        url: apiUrl + webMethod,
        success: function (data) {
            if (data.success) {
                console.log(data.data);
                $("#cmbTipoMaterial").empty();
                $('#cmbTipoMaterial').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.data.length; i++) {
                    $('#cmbTipoMaterial').append($('<option>', {
                        value: data.data[i].id,
                        text: data.data[i].C_0204_0011
                    }));
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {

        }
    });
}
function loadtipoproteccioncatodica() {
    var webMethod = "get_tipoproteccioncatodica";
    $.ajax({
        type: "GET",
        url: apiUrl + webMethod,
        success: function (data) {
            if (data.success) {
                console.log(data.data);
                $("#cmbTipocato").empty();
                $('#cmbTipocato').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.data.length; i++) {
                    $('#cmbTipocato').append($('<option>', {
                        value: data.data[i].id,
                        text: data.data[i].C_0310_116
                    }));
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {

        }
    });
}


function loadtipoinstalacion() {
    var webMethod = "get_tipoinstalacion";
    $.ajax({
        type: "GET",
        url: apiUrl + webMethod,
        success: function (data) {
            if (data.success) {
                console.log(data.data);
                $("#cmbtipinstprot").empty();
                $('#cmbtipinstprot').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.data.length; i++) {
                    $('#cmbtipinstprot').append($('<option>', {
                        value: data.data[i].id,
                        text: data.data[i].C_0310_117
                    }));
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {

        }
    });
}

function loadtipotecnica() {
    var webMethod = "get_tipotecnica";
    $.ajax({
        type: "GET",
        url: apiUrl + webMethod,
        success: function (data) {
            if (data.success) {

                $("#cmtiptecnicaunion").empty();
                $('#cmtiptecnicaunion').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.data.length; i++) {

                    $('#cmtiptecnicaunion').append($('<option>', {
                        value: data.data[i].id,
                        text: data.data[i].C_0302_0049
                    }));
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {

        }
    });
}

function loadtipoubicacion() {
    var webMethod = "get_tipoubicacion";
    $.ajax({
        type: "GET",
        url: apiUrl + webMethod,
        success: function (data) {
            if (data.success) {
                console.log(data.data);
                $("#cmbmetubicsoldunion").empty();
                $('#cmbmetubicsoldunion').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.data.length; i++) {
                    $('#cmbmetubicsoldunion').append($('<option>', {
                        value: data.data[i].id,
                        text: data.data[i].C_0302_0054
                    }));
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {

        }
    });
}


function loadDuctos() {
    var webMethod = "ductos/fetch";
    var params = {
        property: 2,
    };
    $.ajax({
        type: "POST",
        url: apiUrl + webMethod,
        data: params,
        success: function (data) {
            if (data.length > 0 && data !== undefined) {
                console.log(data.data);
                $("#cmbDucto").empty();
                $('#cmbDucto').append($('<option>', {
                    value: 0,
                    text: 'Selecciona...'
                }));
                for (var i = 0; i < data.length; i++) {                  
                    $('#cmbDucto').append($('<option>', {
                        value: data[i].id,
                        text: data[i].nombre
                    }));
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {

        }
    });
}
function reg_newArea() {
    reiniciarForms();
}
function reiniciarForms() {
    $('#registro').show();
    $('#forms').hide();
    $('#step-1').show();
    $('#step-2').hide();
    $('#step-3').hide();
    $('#disenioforms').hide();
    loadDuctos();
    $("#cmbTramo").empty();
    $('#cmbTramo').append($('<option>', {
        value: 0,
        text: 'Selecciona...'
    }));
    $("#cmbAreas").empty();
    $('#cmbAreas').append($('<option>', {
        value: 0,
        text: 'Selecciona...'
    }));
}

function atras_pasodos() {
    $('#step-1').show();
    $('#step-2').hide();
}
function atras_pasotres() {
    $('#step-2').show();
    $('#step-3').hide();
}
function saveDisenioGral() {
    var miCadena = $("#fec_fab").val();
    miCadena= miCadena.replace(/["']/g, "");
    var webMethod = "saveIdentificacion";
    if ($("#diam_in").val() != "") {
        var params = {
            area_unitaria_id: area,
            longitud: $("#longitud").val(),
            diametro_mm: $("#diam_mm").val(),
            espesor_mm: $("#esp_mm").val(),
            tipo_material_disenio: $("#cmbTipoMaterial").val(),
            temp_c: $("#temp_c").val(),
            tipo_costura: $("#cmbTipoCostura").val(),
            fecha_fab: $("#fec_fab").val(),
            porcentaje_carbono: $("#porc_carbono").val(),
            resistencia_traccion: $("#res_trac").val(),
            resistencia_elastico: $("#lim_elas").val(),
            coordenada_especifica: $("#coord_esp_iden_x").val()+' '+$("#coord_esp_iden_y").val(),
            kilometro_especifico: $("#km_esp_iden").val(),
            fec_fab_fin: $("#fec_fab_fin").val(),
            diametro_nominal: $("#cmbunidaddiametro").val(),
            espesor_pared: $("#cmbunidadespesor").val(),
            temperatura: $("#cmbunidadtemperatura").val()
        };


        console.log(JSON.stringify(params))
        fetch(apiUrl + webMethod, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(params)
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                console.log(response)
                return response.json();

            })
            .then(data => {
                if (data.success) {
                    console.log(data.data);
                    alert("Información almacenada correctamente");
                    $('#disenioforms').show();
                    $('#identificacionfrm').hide();
                    loadidentificacion();

                }
            })
            .catch(error => {
                alert("Error: " + error);
            });
    }
    else {
        alert("Es necesario ingresar el diámetro en pulgadas para realizar el registro");
    }
}
function savebasecons() {
    var webMethod = "saveConstruccionGeneral";
    if ($("#coord_esp_idenbasecons").val() !== "") {
        const formData = new FormData();

        formData.append("C_0101_0001_id", area)
        // Make sure files are being selected and appended properly
        if ($("#inputGroupFile01")[0].files[0]) {
            formData.append("C_0308_0111", $("#filepruebabasecons")[0].files[0]);
        }
        // Log formData to console for debugging (this will not display the content of the files)
        for (var pair of formData.entries()) {
            console.log(pair[0] + ', ' + pair[1]);
        }
        var params = {
            C_0101_0001_id: area,
            C_0301_0048: $("#fechaconstbase").val(),
            C_0306_0108: $("#metrecubbase").val(),
            C_0307_0109: $("#txttiposuelobaseconst").val(),
            C_0307_0110: $("#txtmatrellenobaseconst").val(),
            C_0308_0110: $("#presionhermebasecons").val(),
            file: formData,
            C_0308_0111: $("#cmtiporecubrimientobase").val(),
            coordenada_especifica: $("#coord_esp_idenbasecons").val(),
            kilometro_especifico: $("#km_esp_idenbasecons").val()
        };
        console.log(JSON.stringify(params))
        fetch(apiUrl + webMethod, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(params)
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                console.log(response)
                return response.json();

            })
            .then(data => {
                if (data.success) {
                    console.log(data.data);
                    alert("Información almacenada correctamente");
                    $('#construforms').show();
                    $('#constbasefrm').hide();
                }
            })
            .catch(error => {
                alert("Error: " + error);
            });
    }
    else {
        alert("Es necesario ingresar el diámetro en pulgadas para realizar el registro");
    }
}
function saveotroMaterialDisenio() {
    var webMethod = "saveTypeMaterial";
    var params = {
        C_0204_0011: $("#newTipoMaterial").val(),
        descripcion: $("#newDescMaterial").val()
    };


    console.log(JSON.stringify(params))
    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            console.log(response)
            return response.json();

        })
        .then(data => {
            if (data.success) {
                console.log(data.data);
                alert("Información almacenada correctamente");
                loadtipomaterialdisenio();
                $("#espMaterial").hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}
function saveotroCostura() {
    var webMethod = "saveTypeCostura";
    var params = {
        C_0208_0029: $("#newTipocostura").val(),
        descripcion: $("#newDescCostura").val()
    };


    console.log(JSON.stringify(params))
    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            console.log(response)
            return response.json();

        })
        .then(data => {
            if (data.success) {
                console.log(data.data);
                alert("Información almacenada correctamente");
                loadtipocostura();
                $("#espCostura").hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}
function cancelotroMaterialDisenio() {
    $("#espMaterial").hide();
}

function cancelotroProteccionCatodica() {
    $("#crearproteccioncatodica").hide();
}

function cancelotroTipoInstalacion() {
    $("#creartipoinstalacion").hide();
}

function cancelotroTipoUbicacion() {
    $("#creartipoubicacionunion").hide();
}
function cancelotroCostura() {
    $("#espCostura").hide();
}
function saveDisenioPresion()  {
    var webMethod = "savePresion";
    var params = {
        area_unitaria_id: area,
        entidad: $("#cmbEntidad").val(),
        fecha_calculo: $("#txtfechacalculo").val(),
        metodo_calculo: $("#txtMetodoCalculo").val(),
        presion_nom_psi: $("#txtPresNomPSI").val(),
        presion_nom_kg: $("#txtPresNomKG").val(),
        presion_dis_psi: $("#txtPresDisenio").val(),
        presion_max_psi: $("#txtPresMaxPSI").val(),
        presion_max_kg: $("#txtPresMaxKG").val(),
        presion_red_psi: $("#txtPresRedPSI").val(),
        presion_red_kg: $("#txtPresRedKG").val(),
        coordenada_especifica: $("#coord_esp_iden_pres_x").val()+' '+$("#coord_esp_iden_pres_y").val(),
        kilometro_especifico: $("#km_esp_iden_pres").val(),
        pres_nominal: $("#cmbunidadpresnominal").val(),
        pres_disenio: $("#cmbunidadpresiondisenio").val(),
        pres_max_ope: $("#cmbunidadpresionmaxope").val(),
        pres_segmento: $("#cmbunidadpresionsegmento").val()


    };
    


    if ($("#txtPresDisenio").val() != ""){

    console.log(JSON.stringify(params))
    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        console.log(response)
        return response.json();
        
    })
    .then(data => {
        if (data.success) {
            console.log(data.data);
            alert("Información almacenada correctamente");
            $('#disenioforms').show();
            $('#presionfrm').hide();
        }
    })
    .catch(error => {
        alert("Error: " + error);
    });

}

else {
    alert("Es necesario ingresar Presión de diseño (PSI)")
}
}
function saveDisenioProteccion() {
    var webMethod = "saveProteccion";
    var params = {
        area_unitaria_id: area,
        tipo_recubrimiento: $("#txtiporecubrimiento").val(),
        tipo_recubrimiento_2: $("#txtiporecubrimiento_2").val(),
        km_inicial_recubrimiento: $("#txtkminicialrecubrimiento").val(),
        km_final_recubrimiento: $("#txtkmfinalrecubrimiento").val(),
        long_total_recubrimiento: $("#txtlongtotalrecubrimiento").val(),
        empresa_aplico_recubrimiento: $("#txtempresaaplicoservicio").val(),
        fecha_inicio_serv: $("#txtfecinicioservicio").val(),
        fecha_fabricacion: $("#txtfecfabrico").val(),
        fecha_instalacion: $("#txtfecinstalacion").val(),
        fecha_instalacion_2: $("#txtfecinstalacion_2").val(),
        fecha_aplicacion: $("#txtfecaplicacion").val(),
        ubicacion_proteccion_ducto: $("#txtubicacionproteccion").val(),
        orden_aplicacion: $("#txtordenaplicacion").val(),
        localizacion: $("#txtlocalizacion").val(),
        temp_max_funcionamiento: $("#txtTempMaxFuncionamiento").val(),
        motivo_instalacion: $("#txtmotivoinstalacion").val(),
        material_fabricacion: $("#txtmaterialfabricacion").val(),
        espesor_recubrimiento: $("#txtespesorrecubrimiento").val(),
        aislamiento_electrico: $("#cmbdecisionAislamiento").val(),
        control_corrosion: $("#cmbdecisionCorrosion").val(),
        coordenada_especifica: $("#coord_esp_iden_prot_x").val() + ' ' + $("#coord_esp_iden_prot_y").val(),
        kilometro_especifico: $("#km_esp_iden_prot").val()

    };

    if ($("#txtiporecubrimiento").val() != "") {
        fetch(apiUrl + webMethod, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(params)
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                console.log(response)
                return response.json();

            })
            .then(data => {
                if (data.success) {
                    console.log(data.data);
                    alert("Información almacenada correctamente");
                    $('#disenioforms').show();
                    $('#proteccionfrm').hide();
                }
            })
            .catch(error => {
                alert("Error: " + error);
            });
    }

}


function saveotroProteccionCatodica() {
    var webMethod = "saveTypeProteccionCatodica";
    var params = {
        C_0310_116: $("#newTipoProteccion").val(),
        descripcion: $("#newDescProteccion").val()
    };


    console.log(JSON.stringify(params))
    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            console.log(response)
            return response.json();

        })
        .then(data => {
            if (data.success) {
                console.log(data.data);
                alert("Información almacenada correctamente");
                loadtipoproteccioncatodica();
                $("#crearproteccioncatodica").hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}



function saveotroTipoInstalacion() {
    var webMethod = "saveTypeInstalacion";
    var params = {
        C_0310_117: $("#newTipoInstalacion").val(),
        descripcion: $("#newDescInstalacion").val()
    };


    console.log(JSON.stringify(params))
    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            console.log(response)
            return response.json();

        })
        .then(data => {
            if (data.success) {
                console.log(data.data);
                alert("Información almacenada correctamente");
                loadtipoinstalacion();
                $("#creartipoinstalacion").hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}


function saveotroTipoTecnica() {
    var webMethod = "saveTypeTecnica";
    var params = {
        C_0302_0049: $("#newTipoTecnica").val(),
        descripcion: $("#newDescTecnica").val()
    };


    console.log(JSON.stringify(params))
    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            console.log(response)
            return response.json();

        })
        .then(data => {
            if (data.success) {
                console.log(data.data);
                alert("Información almacenada correctamente");
                loadtipotecnica();
                $("#creartipotecnicaunion").hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}


function saveotroTipoUbicacion() {
    var webMethod = "saveTypeUbicacion";
    var params = {
        C_0302_0054: $("#newTipoUbicacion").val(),
        descripcion: $("#newDescUbicacion").val()
    };


    console.log(JSON.stringify(params))
    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            console.log(response)
            return response.json();

        })
        .then(data => {
            if (data.success) {
                console.log(data.data);
                alert("Información almacenada correctamente");
                loadtipoubicacion();
                $("#creartipoubicacionunion").hide();
            }
        })
        .catch(error => {
            alert("Error: " + error);
        });
}





function saveDisenioServicio() {

    var webMethod = "disenio_servicio/store";

    const formData = new FormData();
    formData.append("C_0101_0001_id", area)
    // Make sure files are being selected and appended properly
    if($("#inputGroupFile01")[0].files[0]) {
        formData.append("C_0205_0012", $("#inputGroupFile01")[0].files[0]);
    }
    if($("#inputGroupFile02")[0].files[0]) {
        formData.append("C_0205_0013", $("#inputGroupFile02")[0].files[0]);
    }
    if($("#inputGroupFile03")[0].files[0]) {
        formData.append("C_0205_0014", $("#inputGroupFile03")[0].files[0]);
    }
    if($("#inputGroupFile04")[0].files[0]) {
        formData.append("C_0205_0015", $("#inputGroupFile04")[0].files[0]);
    }
    if($("#inputGroupFile05")[0].files[0]) {
        formData.append("C_0205_0016", $("#inputGroupFile05")[0].files[0]);
    }

    // Log formData to console for debugging (this will not display the content of the files)
    for (var pair of formData.entries()) {
        console.log(pair[0] + ', ' + pair[1]);
    }
    fetch(apiUrl + webMethod, {
        method: 'POST',
        headers: {
            'Accept': 'application/json'
        },
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
        
    })
    .then(data => {
        console.log(typeof data)
        console.log(data)
        if (data.success) {
            console.log(data)
            alert("Información almacenada correctamente");
            $('#disenioforms').show();
            $('#serviciofrm').hide();
        }
    })
    .catch(error => {
        alert("Error: " + error);
    });
}







    


function cancelDisenioGeneral() {
    $('#disenioforms').show();
    $('#identificacionfrm').hide();
}
function cancelDisenioPresion() {
    $('#disenioforms').show();
    $('#presionfrm').hide();
}
function cancelDisenioProteccion() {
    $('#disenioforms').show();
    $('#proteccionfrm').hide();
}
function cancelDisenioServicio() {
    $('#disenioforms').show();
    $('#serviciofrm').hide();
}
//function loadAreas(id) {
//    var webMethod = "areas_unitarias";
//    var params = {
//        id: id,
//    };
//    $.ajax({
//        type: "POST",
//        url: apiUrl + webMethod,
//        data: params,
//        success: function (data) {
//            if (data.success) {
//                console.log(data.data);
//                $("#cmbAreas").empty();
//                //$('#cmbAreas').append($('<option>', {
//                //    value: 0,
//                //    text: 'Selecciona!...'
//                //}));
//                var optioninit = new Option("Selecciona!",0, false, true);
//                $("#cmbAreas").append(optioninit);
//                for (var i = 0; i < data.data.length; i++) {
//                    var option = new Option(data.data[i].nombre, data.data[i].id, false, true);
//                    option.setAttribute('data-kminicial', data.data[i].km_inicial);
//                    option.setAttribute('data-kmfinal', data.data[i].km_final);
//                    option.setAttribute('data-kmorigen', data.data[i].km_origen);
//                    option.setAttribute('data-kmdestino', data.data[i].km_destino);
//                    $("#cmbAreas").append(option);
//                    //$('#mydiv').data('myval');
//                    //$('#cmbAreas').append($('<option>', {
//                    //    value: data.data[i].id,
//                    //    text: data.data[i].nombre,
//                    //    kminicial: data.data[i].km_inicial
//                   // }));
//                }
//                $("#cmbAreas").val(0);
//            }
//        },
//        error: function (xhr, ajaxOptions, thrownError) {

//        }
//    });
//}

function clearPersonas() {
    $('#txtnombreP')[0].value = "";
    $('#txtapellidoPP')[0].value = "";
    $('#txtapellidoMP')[0].value = "";
    $('#txtedadP')[0].value = "";
    $('#txtdireccionP')[0].value = "";
    $('#txtObservaciones')[0].value = "";
    $('#txtsexoP')[0].selectedIndex = 0;

}

function addPersonas() {
        var webMethod = "guardarPersona";
            var params = {
                nombre: $('#txtnombreP')[0].value,
                ap_paterno: $('#txtapellidoPP')[0].value,
                ap_materno: $('#txtapellidoMP')[0].value,
                edad: parseInt($('#txtedadP')[0].value),
                direccion: $('#txtdireccionP')[0].value,
                sexo: $('#txtsexoP')[0].value,
                observaciones: $('#txtObservaciones')[0].value,
                email: $('#txtEmail')[0].value
            };
            $.ajax({
                type: "POST",
                url: apiUrl + webMethod,
                data: params,
                success: function (data) {
                    if (data.success) {
                        alert("El Registro ha sido almacenado");
                        clearPersonas();
                        loadPersonas();
                    }
                    else {

                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {

                }
            });
}

function loadidentificacion() {


        $('#tablaPersonas tbody')[0].innerHTML = "";

    var webMethod = "get_diseniogeneral";
    $.ajax({
        type: "GET",
        url: apiUrl + webMethod,
        success: function (data) {
            if (data.success) {
                for (i = 0; i < data.data.length; i++) {
                    var persona = [data.data[i].nombre, data.data[i].C_0201_0006, data.data[i].C_0202_0007, data.data[i].C_0204_0011,
                    data.data[i].C_0208_0029,];
                    llenarTablas(persona, "tablaPersonas");
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {

        }
    });
}

function consulta() {
    var params;
    if (
        $("#cmbDucto_con option:selected").text() !== "Selecciona..." ||
        $("#cmbTramo_con option:selected").text() !== "Selecciona..." ||
        $("#cmbSegmento_con option:selected").text() !== "Selecciona..." ||
        $("#cmbAreas_con option:selected").text() !== "Selecciona..."
    ) {
        if (
            $("#cmbDucto_con option:selected").text() !== "Selecciona..." &&
            $("#cmbTramo_con option:selected").text() == "Selecciona..." &&
            $("#cmbSegmento_con option:selected").text() == "Selecciona..." &&
            $("#cmbAreas_con option:selected").text() == "Selecciona..."
        ) {
            params = {
                id: $("#cmbDucto_con option:selected").val(),
                op:4
            };
        }
        else if (
            $("#cmbDucto_con option:selected").text() !== "Selecciona..." &&
            $("#cmbTramo_con option:selected").text() != "Selecciona..." &&
            $("#cmbSegmento_con option:selected").text() == "Selecciona..." &&
            $("#cmbAreas_con option:selected").text() == "Selecciona..."
        ) {
            params = {
                id: $("#cmbTramo_con option:selected").val(),
                op: 3
            };
        }
        else if (
            $("#cmbDucto_con option:selected").text() !== "Selecciona..." &&
            $("#cmbTramo_con option:selected").text() != "Selecciona..." &&
            $("#cmbSegmento_con option:selected").text() != "Selecciona..." &&
            $("#cmbAreas_con option:selected").text() == "Selecciona..."
        ) {
            params = {
                id: $("#cmbSegmento_con option:selected").val(),
                op: 2
            };
        }
        else if (
            $("#cmbDucto_con option:selected").text() !== "Selecciona..." &&
            $("#cmbTramo_con option:selected").text() != "Selecciona..." &&
            $("#cmbSegmento_con option:selected").text() != "Selecciona..." &&
            $("#cmbAreas_con option:selected").text() != "Selecciona..."
        ) {
            params = {
                id: $("#cmbAreas_con option:selected").val(),
                op: 1
            };
        }
        switch (temaconsulta) {
            case "T1":
                switch (temaconsultadisenio) {
                
                    case "Dis1":
                        $('#tablaPersonas tbody')[0].innerHTML = "";
                        var webMethod = "get_diseniogeneral";
                        $.ajax({
                            type: "POST",
                            url: apiUrl + webMethod,
                            data: params,
                            success: function (data) {
                                if (data.data.length > 0) {
                                    //Diametro mm
                                    $('#diammcons').text(data.data[0].C_0202_0007);
                                    //Diametro in
                                    $('#diaincons').text(data.data[0].C_0202_0008);
                                    //Espesor mm
                                    $('#espmmcons').text(data.data[0].C_0203_0009);
                                    //Espesor in
                                    $('#espincons').text(data.data[0].C_0203_0010);
                                    //Especificación material
                                    $('#espmatcons').text(data.data[0].C_0204_0011);
                                    //Temperatura °C
                                    $('#tempconsc').text(data.data[0].C_0207_0027);
                                    //Temperatura °F
                                    $('#tempconsf').text(data.data[0].C_0207_0028);
                                    //Fecha fabricación
                                    $('#fecfabcons').text(data.data[0].C_0209_0030);
                                    //% carbono
                                    $('#porcons').text(data.data[0].C_0210_0031);
                                    //% resistencia tracción
                                    $('#restraccons').text(data.data[0].C_0210_0032);
                                    //% Límite elástico
                                    $('#limelacons').text(data.data[0].C_0210_0033);
                                }

                                if (data.success) {
                                    for (i = 0; i < data.data.length; i++) {
                                        var persona = [data.data[i].id, data.data[i].areaunitaria, data.data[i].coordenada_especifica, data.data[i].kilometro_especifico, data.data[i].C_0201_0006, data.data[i].C_0208_0029];
                                        llenarTablas(persona, "tablaPersonas");
                                    }
                                    if (data.data.length > 0) {
                                        // ExportarDatos(data.data);
                                    }
                                }
                            },
                            error: function (xhr, ajaxOptions, thrownError) {

                            }
                        });
                        break;                     
                    case "Dis2":
                        $('#tablapresion tbody')[0].innerHTML = "";
                        var webMethodPresion = "get_Presion";
                        $.ajax({
                            type: "POST",
                            url: apiUrl + webMethodPresion,
                            data: params,
                            success: function (data) {
                                if (data.success) {
                                    if (data.data.length > 0) {
                                        //Presión diseño
                                        $('#presdiscons').text(data.data[0].C_0206_0022);
                                        //Presion Max PSI
                                        $('#presmaxoppsicons').text(data.data[0].C_0206_0023);
                                        //Presion Max Kg
                                        $('#presmaxopecons').text(data.data[0].C_0206_0024);
                                    }
                                    for (i = 0; i < data.data.length; i++) {
                                        var persona = [data.data[i].id, data.data[i].areaunitaria, data.data[i].coordenada_especifica, data.data[i].kilometro_especifico, data.data[i].C_0206_0017, data.data[i].C_0206_0019, data.data[i].C_0206_0023, data.data[i].C_0206_0024];
                                        llenarTablas(persona, "tablapresion");
                                    }
                                    if (data.data.length > 0) {
                                        // ExportarDatos(data.data);
                                    }
                                }
                            },
                            error: function (xhr, ajaxOptions, thrownError) {

                            }
                        });
                        break;
                    case "Dis3":
                        $('#tablaproteccion tbody')[0].innerHTML = "";
                        var webMethodProteccion = "get_Proteccion";
                        $.ajax({
                            type: "POST",
                            url: apiUrl + webMethodProteccion,
                            data: params,
                            success: function (data) {
                                if (data.success) {
                                    for (i = 0; i < data.data.length; i++) {
                                        var persona = [data.data[i].id, data.data[i].areaunitaria, data.data[i].coordenada_especifica, data.data[i].kilometro_especifico, data.data[i].C_0211_0043, data.data[i].C_0211_0044, data.data[i].C_0211_0045, data.data[i].C_0211_0046];
                                        llenarTablas(persona, "tablaproteccion");
                                    }
                                    if (data.data.length > 0) {
                                        // ExportarDatos(data.data);
                                    }
                                }
                            },
                            error: function (xhr, ajaxOptions, thrownError) {

                            }
                        });
                        break;
                    default:
                }             
                break;
            case "T2":
                switch (temaconsultaconstruccion) {
                    case "Cons1":
                        $('#tablabasecons tbody')[0].innerHTML = "";
                        var webMethodCatodica = "get_construcciongeneral";
                        $.ajax({
                            type: "POST",
                            url: apiUrl + webMethodCatodica,
                            data: params,
                            success: function (data) {
                                if (data.success) {
                                    if (data.data.length > 0) {
                                        //Fecha construcción
                                        $('#tipocatodicacons').text(data.data[0].C_0301_0048);
                                        //Recubrimiento anticorrosivo
                                        $('#recuanticorro').text(data.data[0].C_0306_0108);
                                        //Tipo de suelo
                                        $('#tiposueloconsbase').text(data.data[0].C_0307_0109);
                                        //Material de relleno
                                        $('#matrellenobasecons').text(data.data[0].C_0307_0110);
                                        //Tipo recubrimiento
                                        $('#tiporecconsbase').text(data.data[0].C_0311_121);
                                    }
                                    for (i = 0; i < data.data.length; i++) {
                                        var persona = [data.data[i].id, data.data[i].areaunitaria, data.data[i].coordenada_especifica, data.data[i].kilometro_especifico, data.data[i].C_0308_0110];
                                        llenarTablas(persona, "tablabasecons");
                                    }
                                    if (data.data.length > 0) {
                                        // ExportarDatos(data.data);
                                    }
                                }
                            },
                            error: function (xhr, ajaxOptions, thrownError) {

                            }
                        });
                        break;
                    case "Cons2":
                        $('#tablaunionCons tbody')[0].innerHTML = "";
                        var webMethodUnion = "get_construccionunion";
                        $.ajax({
                            type: "POST",
                            url: apiUrl + webMethodUnion,
                            data: params,
                            success: function (data) {
                                if (data.success) {

                                    for (i = 0; i < data.data.length; i++) {
                                        var persona = [data.data[i].id, data.data[i].areaunitaria, data.data[i].coordenada_especifica, data.data[i].kilometro_especifico, data.data[i].C_0302_0049, data.data[i].C_0302_0050, data.data[i].C_0302_0051, data.data[i].C_0302_0052];
                                        llenarTablas(persona, "tablaunionCons");
                                    }
                                    if (data.data.length > 0) {
                                        // ExportarDatos(data.data);
                                    }
                                }
                            },
                            error: function (xhr, ajaxOptions, thrownError) {

                            }
                        });
                        break;
                    case "Cons3":
                        $('#tablaProfundidad tbody')[0].innerHTML = "";
                        var webMethodProfundidad = "get_construccionprofundidad";
                        $.ajax({
                            type: "POST",
                            url: apiUrl + webMethodProfundidad,
                            data: params,
                            success: function (data) {
                                if (data.success) {
                                    
                                    for (i = 0; i < data.data.length; i++) {
                                        var persona = [data.data[i].id, data.data[i].areaunitaria, data.data[i].coordenada_especifica, data.data[i].kilometro_especifico, data.data[i].C_0303_0058, data.data[i].C_0303_0059, data.data[i].C_0303_0060, data.data[i].C_0303_0061];
                                        llenarTablas(persona, "tablaProfundidad");
                                    }
                                    if (data.data.length > 0) {
                                        // ExportarDatos(data.data);
                                    }
                                }
                            },
                            error: function (xhr, ajaxOptions, thrownError) {

                            }
                        });
                        break;
                    case "Cons4":
                        $('#tablaConsCruces tbody')[0].innerHTML = "";
                        var webMethodCruces = "get_construccioncruces";
                        $.ajax({
                            type: "POST",
                            url: apiUrl + webMethodCruces,
                            data: params,
                            success: function (data) {
                                if (data.success) {
                                    for (i = 0; i < data.data.length; i++) {
                                        var persona = [data.data[i].id, data.data[i].areaunitaria, data.data[i].coordenada_especifica, data.data[i].kilometro_especifico, data.data[i].C_0304_0070, data.data[i].C_0304_0071, data.data[i].C_0304_0072, data.data[i].C_0304_0073, data.data[i].C_0304_0074, data.data[i].C_0304_0075];
                                        llenarTablas(persona, "tablaConsCruces");
                                    }
                                    if (data.data.length > 0) {
                                        // ExportarDatos(data.data);
                                    }
                                }
                            },
                            error: function (xhr, ajaxOptions, thrownError) {

                            }
                        });
                        break;
                    case "Cons5"://tablaHermeticidad
                        $('#tablaHermeticidad tbody')[0].innerHTML = "";
                        var webMethodHermeticidad = "get_construccionhermeticidad";
                        $.ajax({
                            type: "POST",
                            url: apiUrl + webMethodHermeticidad,
                            data: params,
                            success: function (data) {
                                if (data.success) {
                                    if (data.data.length > 0) {
                                        //Tipo catódica
                                        $('#tipocatodicacons').text(data.data[0].C_0310_116);
                                    }
                                    for (i = 0; i < data.data.length; i++) {
                                        var persona = [data.data[i].id, data.data[i].areaunitaria, data.data[i].coordenada_especifica, data.data[i].kilometro_especifico, data.data[i].C_0305_0097, data.data[i].C_0305_0098, data.data[i].C_0305_0099, data.data[i].C_0305_0100, data.data[i].C_0305_0101];
                                        llenarTablas(persona, "tablaHermeticidad");
                                    }
                                    if (data.data.length > 0) {
                                        // ExportarDatos(data.data);
                                    }
                                }
                            },
                            error: function (xhr, ajaxOptions, thrownError) {

                            }
                        });
                        break;
                    case "Cons7":
                        $('#tablaConsCatodica tbody')[0].innerHTML = "";
                        var webMethodCatodica = "get_construccioncatodica";
                        $.ajax({
                            type: "POST",
                            url: apiUrl + webMethodCatodica,
                            data: params,
                            success: function (data) {
                                if (data.success) {
                                    if (data.data.length > 0) {
                                        //Tipo catódica
                                        $('#tipocatodicacons').text(data.data[0].C_0310_116);
                                    }
                                    for (i = 0; i < data.data.length; i++) {
                                        var persona = [data.data[i].id, data.data[i].areaunitaria, data.data[i].coordenada_especifica, data.data[i].kilometro_especifico, data.data[i].C_0310_117, data.data[i].C_0310_118, data.data[i].C_0310_119, data.data[i].C_0310_120, data.data[i].nombre];
                                        llenarTablas(persona, "tablaConsCatodica");
                                    }
                                        if (data.data.length > 0) {
                                            // ExportarDatos(data.data);
                                        }
                                    }
                                },
                                error: function (xhr, ajaxOptions, thrownError) {

                                }
                            });
                        break;
                    default:
                }
                
                break;
            case "T3":
               
                break;
            default:
        }

    }
    else {
        alert("Es necesario seleccionar al menos un tipo para realizar la búsqueda");
    }
   
}
function OcultarConstruccionConsulta() {
    $("#tablabasecons").hide();
    $("#databasegeneral").hide();
    $("#tablaunionCons").hide();
    $("#tablaProfundidad").hide();
    $("#tablaConsCruces").hide();
    $("#tablaHermeticidad").hide();
    $("#tablaConsCatodica").hide();
    $("#datacatodica").hide();
}
function ExportarDatos(registros) {


    var encabezados = Object.keys(registros[0]);


    var datos = [encabezados];
    registros.forEach(function (registro) {
        var fila = encabezados.map(function (encabezado) {
            return registro[encabezado];
        });
        datos.push(fila);
    });

    // Creamos una hoja de cálculo
    const hoja = XLSX.utils.aoa_to_sheet(datos);
    const libro = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(libro, hoja, "Datos");
    const nombreArchivo = "dtp.xlsx";
    const libroBuffer = XLSX.write(libro, { bookType: "xlsx", type: "array" });
    const archivoExcel = new Blob([libroBuffer], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
    saveAs(archivoExcel, nombreArchivo);
}


function loadDisenioGral() {


    $('#tablaPersonas tbody')[0].innerHTML = "";

    var webMethod = "obtenerPersonas";
    $.ajax({
        type: "GET",
        url: apiUrl + webMethod,
        success: function (data) {
            if (data.success) {
                for (i = 0; i < data.data.length; i++) {
                    var persona = [data.data[i].id,data.data[i].nombre, data.data[i].C_0201_0006, data.data[i].C_0202_0007, data.data[i].C_0204_0011,data.data[i].C_0208_0029,];
                    llenarTablas(persona, "tablaPersonas");
                }
            }
        },
        error: function (xhr, ajaxOptions, thrownError) {

        }
    });
}

function llenarTablas(obj, nameTabla) {
   // $('#tablaPersonas tbody')[0].innerHTML = "";
    var row = '<tr>';
    for (j = 1; j < obj.length; j++) {
        row = row + '<td>' + obj[j] + '</td>';
    }
    row = row + '<td><a class="add" title="Guardar" data-toggle="tooltip"id="ra' + obj[0] + '" data-id="' + obj[0] +'"><i class="fa fa-floppy-disk"></i></a> &nbsp;&nbsp;<a class="edit" title="Editar" data-toggle="tooltip" id="re' + obj[0] + '" data-id="' + obj[0] +'"><i class="fa fa-pen"></i></a>&nbsp;&nbsp;<a class="delete" title="Eliminar" data-toggle="tooltip" data-id="' + obj[0] +'"><i class="fa fa-trash"></i></a></td>';
    row = row + '</tr>';
    
   $('#' + nameTabla + ' tbody').append(row);
}


function llenar_ductos(){


    const webMethod='ductos';
        url=apiUrl+webMethod;
      fetch(url, {
        method: 'GET', // or 'POST', 'PUT', etc.
        headers: headers
      })
          .then(response => response.json())
          .then(data => {
              var selectElement = document.getElementById("cmbDucto");
              var selectElementConsulta = document.getElementById("cmbDucto_con");
              data.ductos.forEach(item => {
                var option = document.createElement("option");
                option.value = item.id; // Using the 'id' property as value
                option.text = item.nombre; // Using the 'nombre' property as display name
                  selectElement.add(option);
                  var option2 = document.createElement("option");
                  option2.value = item.id; // Using the 'id' property as value
                  option2.text = item.nombre; // Using the 'nombre' property as display name
                  selectElementConsulta.add(option);
            });
          })
          .catch(error => console.error("Error fetching data: ", error));
}

$('#cmbDucto').change(function() {
    $("#cmbTramo option:not(:first)").remove();
    var property = $(this).val();
    const webMethod='tramos/fetch';
        url=apiUrl+webMethod;
    if (property) {      
      fetch(url, {
        method: 'POST', // or 'POST', 'PUT', etc.
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({'property': property})
      })
          .then(response => response.json())
          .then(data => {
            console.log(data)
              var selectElement = document.getElementById("cmbTramo");
              console.log(data)
              data.forEach(item => {
                var option = document.createElement("option");
                option.value = item.id; // Using the 'id' property as value
                option.text = item.nombre; // Using the 'nombre' property as display name
                selectElement.add(option);
            });
          })
          .catch(error => console.error("Error fetching data: ", error));
    }
  });


//Validation
$(document).ready(function(){
    $(".validate-pattern").on('input', function(e){
        var pattern = new RegExp($(this).attr('pattern'));
        if($(this).val() === ""){
            // If input is empty, remove both classes
            $(this).removeClass('is-valid is-invalid');
        } else if(pattern.test($(this).val())){
            // If input matches pattern, add 'is-valid' and remove 'is-invalid'
            $(this).removeClass('is-invalid');
            $(this).addClass('is-valid');
        } else {
            // If input does not match pattern, add 'is-invalid' and remove 'is-valid'
            $(this).removeClass('is-valid');
            $(this).addClass('is-invalid');
        }
    });
});




function validateForm(formId, saveFn) {
    const form = document.getElementById(formId);
    const inputs = form.querySelectorAll('.form-control');

    let allInputsValidated = true;

    inputs.forEach(input => {
        if (input.classList.contains('is-invalid')) {
            allInputsValidated = false;
        }
    });

    if (allInputsValidated) {
        saveFn();
    } else {
        alert('Verifique que todos los datos ingresados sean correctos');
    }
}





document.addEventListener("DOMContentLoaded", function() {
    // Get the dropdown element
    const tipoCruceDropdown = document.getElementById("cmbTipcruce");

    // Add event listener for change event
    tipoCruceDropdown.addEventListener("change", function() {
        // Hide all the classes first
        hideAllClasses();

        // Get the selected value
        const selectedValue = this.value;

        // Show the respective class based on the selected value
        switch (selectedValue) {
            case "1":
                showClass("acuatico");
                break;
            case "2":
                showClass("acuatico");
                break;
            case "3":
                showClass("infraestructura");
                break;
            case "4":
                showClass("extranjeros");
                break;
            case "5":
                showClass("comunicacion");
                break;
        }
    });
});

function hideAllClasses() {
    hideClass("acuatico");
    hideClass("infraestructura");
    hideClass("extranjeros");
    hideClass("comunicacion");
}

function hideClass(className) {
    const elements = document.querySelectorAll("." + className);
    elements.forEach(element => {
        element.style.display = "none";
    });
}

function showClass(className) {
    const elements = document.querySelectorAll("." + className);
    elements.forEach(element => {
        element.style.display = "";
    });
}